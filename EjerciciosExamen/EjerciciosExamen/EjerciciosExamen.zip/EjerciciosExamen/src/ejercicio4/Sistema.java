package ejercicio4;

public class Sistema {
}
